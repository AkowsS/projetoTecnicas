/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

import javax.swing.JOptionPane;




public class Menu extends javax.swing.JFrame {

    
    public Menu() {
        initComponents();
        
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        menusaque = new javax.swing.JToggleButton();
        menudepos = new javax.swing.JToggleButton();
        menutransf = new javax.swing.JToggleButton();
        menureajuste = new javax.swing.JToggleButton();
        menusair = new javax.swing.JToggleButton();
        menuSaldo = new javax.swing.JButton();

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setLocation(new java.awt.Point(0, 0));
        setResizable(false);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        jLabel1.setText("Menu");

        menusaque.setText("Saque");
        menusaque.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menusaqueActionPerformed(evt);
            }
        });

        menudepos.setText("Depósito");
        menudepos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menudeposActionPerformed(evt);
            }
        });

        menutransf.setText("Transfêrencia");
        menutransf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menutransfActionPerformed(evt);
            }
        });

        menureajuste.setText("Reajuste");
        menureajuste.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menureajusteActionPerformed(evt);
            }
        });

        menusair.setText("Sair ");
        menusair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menusairActionPerformed(evt);
            }
        });

        menuSaldo.setText("Ver saldo");
        menuSaldo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuSaldoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(menusair, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(menusaque, javax.swing.GroupLayout.DEFAULT_SIZE, 135, Short.MAX_VALUE)
                    .addComponent(menudepos, javax.swing.GroupLayout.DEFAULT_SIZE, 135, Short.MAX_VALUE)
                    .addComponent(menutransf, javax.swing.GroupLayout.DEFAULT_SIZE, 135, Short.MAX_VALUE)
                    .addComponent(menureajuste, javax.swing.GroupLayout.DEFAULT_SIZE, 135, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(50, 50, 50))
                    .addComponent(menuSaldo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(menusaque)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(menudepos)
                .addGap(11, 11, 11)
                .addComponent(menutransf)
                .addGap(11, 11, 11)
                .addComponent(menureajuste)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(menuSaldo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 41, Short.MAX_VALUE)
                .addComponent(menusair, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void menusairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menusairActionPerformed
       System.exit(0);
    }//GEN-LAST:event_menusairActionPerformed

    private void menureajusteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menureajusteActionPerformed
        
        new reajuste().setVisible(true);
        this.setVisible(false);
        
    }//GEN-LAST:event_menureajusteActionPerformed

    private void menusaqueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menusaqueActionPerformed
       
       new Sacar().setVisible(true);
       this.setVisible(false);      

    }//GEN-LAST:event_menusaqueActionPerformed

    private void menudeposActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menudeposActionPerformed
       
       new Deposito().setVisible(true);
       this.setVisible(false);
        
    }//GEN-LAST:event_menudeposActionPerformed

    private void menutransfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menutransfActionPerformed
        
       new Transferir().setVisible(true);
       this.setVisible(false);
        
    }//GEN-LAST:event_menutransfActionPerformed

    private void menuSaldoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuSaldoActionPerformed
      JOptionPane.showMessageDialog(null, Principal.cc.getNumeroCorrente()+", sua conta "+ Principal.cc.getTipoConta()+" possui R$: "+Principal.cc.getSaldoCorrente()+"\n"
      +Principal.cp.getNumeropoupanca()+", sua conta "+ Principal.cp.getTipoConta()+" possui R$: "+Principal.cp.getSaldopoupanca()+"\n"
      +Principal.cep.getNomeEspecial()+", sua conta "+ Principal.cep.getTipoConta()+" possui R$: "+Principal.cep.getSaldoEspecial()+"\n");
    }//GEN-LAST:event_menuSaldoActionPerformed

    /**
     * @param args the command line arguments
     */
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JButton menuSaldo;
    private javax.swing.JToggleButton menudepos;
    private javax.swing.JToggleButton menureajuste;
    private javax.swing.JToggleButton menusair;
    private javax.swing.JToggleButton menusaque;
    private javax.swing.JToggleButton menutransf;
    // End of variables declaration//GEN-END:variables
}
