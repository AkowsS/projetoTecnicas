/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

import javax.swing.JOptionPane;

/**
 *
 * @author ailto
 */
public class Deposito extends javax.swing.JFrame {
    
    public Deposito() {
        initComponents();
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        valdeposito = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        numconta = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        backmenu = new javax.swing.JButton();
        deposef = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel1.setText("Valor a ser depositado: ");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("Confirme o numero da conta:");

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel3.setText("Tela de Depósito");

        backmenu.setText("Voltar ao Menu");
        backmenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backmenuActionPerformed(evt);
            }
        });

        deposef.setText("Depositar ");
        deposef.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deposefActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(98, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addGap(89, 89, 89))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(43, 43, 43)
                        .addComponent(valdeposito))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(numconta))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(backmenu)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(deposef, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(valdeposito, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(54, 54, 54)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(numconta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 109, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(deposef, javax.swing.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE)
                    .addComponent(backmenu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void backmenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backmenuActionPerformed

        
       new Menu().setVisible(true);
       this.setVisible(false);
        
        
    }//GEN-LAST:event_backmenuActionPerformed

    private void deposefActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deposefActionPerformed
        
        double valordepos = Double.parseDouble(valdeposito.getText());  //valor a ser retirado
        int numerocont = Integer.parseInt(numconta.getText());  // confirmação do numero da conta
        
        int ver = 0;
        
        if(numerocont == Principal.cc.getNumeroCorrente())
        {
            ver = 1;
            Principal.cc.setSaldoCorrente(valordepos);
            if(Principal.cc.flag==1)
            {
                JOptionPane.showMessageDialog(null,"Conta "+Principal.cc.getTipoConta()+"\n"+"Deposito efetuado com sucesso \nSaldo atual: "+ Principal.cc.getSaldoCorrente()); 
        
            }
            
        }
        if(numerocont == Principal.cp.getNumeropoupanca())
        {
            ver = 1;
            Principal.cp.setSaldopoupanca(valordepos);
            
            if(Principal.cp.flag == 1)
            {
                
                JOptionPane.showMessageDialog(null,"Conta "+Principal.cp.getTipoConta()+"\n"+"Deposito efetuado com sucesso \nSaldo atual: "+ Principal.cp.getSaldopoupanca()); 
        
            }
            
        }
        if(numerocont == Principal.cep.getNumeroEspecial())
        {
            ver = 1;
            Principal.cep.setSaldoEspecial(valordepos);
            if(Principal.cep.flag == 1)
            {
                     JOptionPane.showMessageDialog(null,"Conta "+Principal.cep.getTipoConta()+"\n"+"Deposito efetuado com sucesso \nSaldo atual: "+ Principal.cep.getSaldoEspecial()); 
       
            }
        }
        
        
        if(ver == 0){
            JOptionPane.showMessageDialog(null, "Um dos campos nao foi preenchido corretamente, por favor verifique e reenvie.");
        }
        
    }//GEN-LAST:event_deposefActionPerformed

   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backmenu;
    private javax.swing.JButton deposef;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JTextField numconta;
    private javax.swing.JTextField valdeposito;
    // End of variables declaration//GEN-END:variables
}
