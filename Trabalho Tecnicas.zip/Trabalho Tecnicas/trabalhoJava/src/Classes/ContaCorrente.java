/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

import javax.swing.JOptionPane;

/**
 *
 * @author ailto
 */
class ContaCorrente {
    private String nomeCorrente;
    private String senhaCorrente;
    private int numeroCorrente;
    private double saldoCorrente;
    private double depositar;
    private double sacar;
    private String tipoConta;
    private double tranferir;
    public int flag;

    public String getNomeCorrente() {
        return nomeCorrente;
    }

    public void setNomeCorrente(String nomeCorrente) {
        this.nomeCorrente = nomeCorrente;
    }

    public String getSenhaCorrente() {
        return senhaCorrente;
    }

    public void setSenhaCorrente(String senhaCorrente) {
        this.senhaCorrente = senhaCorrente;
    }

    public int getNumeroCorrente() {
        return numeroCorrente;
    }

    public void setNumeroCorrente(int numeroCorrente) {
        this.numeroCorrente = numeroCorrente;
    }

    public double getSaldoCorrente() {
        return saldoCorrente;
    }

    public void setSaldoCorrente(double saldoCorrente) {
        this.saldoCorrente += saldoCorrente;
    }

    public double getDepositar() {
        return depositar;
    }

    public void setDepositar(double depositar) {
        this.flag = 0;
        
        if( depositar < 0)
        {
            JOptionPane.showMessageDialog(null, "Depósito nao efetuado");
            
        }else{
            this.saldoCorrente += depositar;
            this.flag = 1;
        }
        
    }

    public double getSacar() {
        return sacar;
    }

    public void setSacar(double sacar) {
        
        flag = 0;
        
        if(sacar > saldoCorrente)
        {
            JOptionPane.showMessageDialog(null, "Saldo Insuficiente!");
        }
        else if(sacar <= 0)
        {
            JOptionPane.showMessageDialog(null, "O saque nao pode ser efetuado!");
        }
        else
        {
            flag = 1;
            this.saldoCorrente = this.saldoCorrente - sacar;
        }
        
    }

    public String getTipoConta() {
        tipoConta = "Corrente";
        return tipoConta;
    }

    public void setTipoConta(String tipoConta) {
        String tipoConta1 = this.tipoConta;
        
    }

    public double getTranferir() {
        return tranferir;
    }

    public void setTranferir(double tranferir) {
        this.tranferir = tranferir;
    }
    
    
    
    
}
