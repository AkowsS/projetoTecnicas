/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

import javax.swing.JOptionPane;

/**
 *
 * @author ailto
 */
class ContaPoupanca extends ContaCorrente {
    
    private String nomePoupanca;
    private String senhapoupanca;
    private int numeropoupanca;
    private double saldopoupanca;
    private double depositar;
    private double sacar;
    private String tipoConta;
    private double tranferir;
    private double reajustar;
    public int flag;

    public String getNomePoupanca() {
        return nomePoupanca;
    }

    public void setNomePoupanca(String nomePoupanca) {
        this.nomePoupanca = nomePoupanca;
    }

    public String getSenhapoupanca() {
        return senhapoupanca;
    }

    public void setSenhapoupanca(String senhapoupanca) {
        this.senhapoupanca = senhapoupanca;
    }

    public int getNumeropoupanca() {
        return numeropoupanca;
    }

    public void setNumeropoupanca(int numeropoupanca) {
        this.numeropoupanca = numeropoupanca;
    }

    public double getSaldopoupanca() {
        return saldopoupanca;
    }

    public void setSaldopoupanca(double saldopoupanca) {
        this.saldopoupanca += saldopoupanca;
    }

    @Override
    public double getDepositar() {
        return depositar;
    }

    @Override
    public void setDepositar(double depositar) {
        flag = 0;
        if( depositar < 0)
        {
            JOptionPane.showMessageDialog(null, "Depósito nao efetuado");
        }else{
            this.saldopoupanca += depositar;
            flag = 1;
        }
    }

    @Override
    public double getSacar() {
        return sacar;
    }

    @Override
    public void setSacar(double sacar) {
        this.flag = 0;
        
        if(sacar>saldopoupanca)
        {
            JOptionPane.showMessageDialog(null, "Saldo Insuficiente!");
        }
        if(sacar < 0)
        {
            JOptionPane.showMessageDialog(null, "O saque nao pode ser efetuado!");
        }
        if(sacar < saldopoupanca && sacar >0)
        {
            this.flag = 1;
            this.saldopoupanca -= sacar;
        }
    }

    @Override
    public String getTipoConta() {
        tipoConta = "Poupança";
        return tipoConta;
    }

    @Override
    public void setTipoConta(String tipoConta) {
        this.tipoConta = tipoConta;
    }

    @Override
    public double getTranferir() {
        return tranferir;
    }

    @Override
    public void setTranferir(double tranferir) {
        this.tranferir = tranferir;
    }

    public double getReajustar() {
        return reajustar;
    }

    public void setReajustar(double reajustar) {
        
        this.saldopoupanca += ((reajustar/100)*saldopoupanca);
    }
}
